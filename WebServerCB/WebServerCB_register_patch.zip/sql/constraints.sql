ALTER TABLE tbl_Usuario ADD UNIQUE INDEX ux_usuario (Usuario);
ALTER TABLE tbl_Usuario ADD UNIQUE INDEX ux_correo  (Correo);
