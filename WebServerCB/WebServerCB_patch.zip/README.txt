Instrucciones (Backend):
1) Copia `models/index.js` dentro de `WebServerCB/models/`.
2) Si no tienes `app.js`, puedes usar el incluido (CORS universal y rutas /api).
3) Asegura variables .env: DB_* (MySQL), DB_DIALECT=mysql, JWT_SECRET.
4) Reinicia el servidor.
